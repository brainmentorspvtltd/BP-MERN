import React from 'react'
import { Cart } from '../components/Cart'

export const CartView = () => {
  return (
    <>
        <Cart/>
    </>
  )
}
