import express from 'express';
const app = express();
app.get('/products', (request, response)=>{
   // response.send("<h2>Hello Products....</h2>");
   // 3 Products
   response.json({id:1001, name:'Ram'});
})
app.listen(4444, err=>{
    if(err){
        console.log('Error in App ', err);
    }
    else{
        console.log('Server Up and Running ');
    }
})