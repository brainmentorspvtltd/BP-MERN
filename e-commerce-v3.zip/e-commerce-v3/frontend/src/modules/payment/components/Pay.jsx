import React from 'react'

export const Pay = () => {
  return (
    <button className='btn btn-primary'>Pay Now</button>
  )
}
