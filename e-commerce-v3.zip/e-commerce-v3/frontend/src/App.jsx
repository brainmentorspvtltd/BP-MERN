import React from 'react'
import { DashBoard } from './modules/dashboard/pages/DashBoard'

const App = () => {
  return (
    <div>
      <DashBoard/>
    </div>
  )
}

export default App