import React from 'react'

export const Header = () => {
  return (
    <div className = 'alert alert-info'>
        <h3>Pizza Factory Shop</h3>

    </div>
  )
}
