import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import { createConnection } from './shared/db/connection.js';
import { productRoutes } from './modules/products/routes/product-routes.js';
const app = express();
dotenv.config();
app.use(cors());
app.use(express.json());
app.use('/', productRoutes);
// app.use('/',orderRoutes);
// app.get('/products', (request, response)=>{
//    // response.send("<h2>Hello Products....</h2>");
//    // 3 Products
//    response.json({id:1001, name:'Ram'});
// })
const promise = createConnection();
promise.then((conInfo)=>{
    console.log('DB Connection Establish');
    app.listen(process.env.PORT || 4444, err=>{
        if(err){
            console.log('Error in App ', err);
        }
        else{
            console.log('Server Up and Running ');
        }
    })
}).catch(err=>{
    console.log('DB Connection is Down...',err);
})
