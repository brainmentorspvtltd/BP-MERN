var buttons = document.
getElementsByTagName('button');
console.log('Buttons are ', buttons);
for(var i = 0; i<buttons.length; i++){
    var currentButton = buttons[i];
    currentButton.addEventListener('click', 
    printXorZero);
}
var flag = true;
function printXorZero(){
    // this -keyword
    // current calling object reference
    var currentButton = this;
    // <button>INNERTEXT</button>
    //alert("Clicked Happen");
    var value = flag?"X":"0";
    currentButton.innerText = value;
    flag = !flag;
}