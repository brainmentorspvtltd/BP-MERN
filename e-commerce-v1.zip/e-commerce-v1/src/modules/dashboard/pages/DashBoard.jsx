import React, { useEffect } from 'react'
import { Products } from '../components/Products'
import { Header } from '../../../shared/components/Header'
import { getApi } from '../../../shared/services/api-client';

export const DashBoard = () => {
  useEffect(()=>{
      getProducts();
  },[]) ; // Mounting
  const getProducts = async ()=>{
     const data = await getApi();
  }
  return (
    <div className='container'>
      <Header/>
      {loading?<p>Loading...</p>:<Products/>}
      
    </div>
  )
}
