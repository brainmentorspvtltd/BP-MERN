import React from "react";
import { CounterApp } from "./pages/CounterApp";

function App(){
    return (<CounterApp/>);
   
    // return React.createElement('div', {className:'red'},
    // React.createElement('h1', null, 'Hello react js'),
    // React.createElement('h2', null, 'hi react js'));
    // return (<div class='red'>
    //     <h1>Hello React JS</h1>
    //     <h2> Hi React JS</h2>
    // </div>)
 // return (<h1>Hello React JS</h1>)
 //return React.createElement('h1', null, 'Hello React JS');
}
export default App;
