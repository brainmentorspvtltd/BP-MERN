// Arrow Function ES6 
// Arrow Function best use for One line function
// one line function it return implicit
// Arrow function - object creation (new can't be use)
// Pure Function
export const Button = (props)=>{
    return (<button onClick={props.fn} className={props.color}>{props.val}</button>);
}
