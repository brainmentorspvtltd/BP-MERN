// Map JSX to DOM
// App Component render div 
// App Component -JSX -- VDOM -- ReactDOM ---   DOM
import App from "./App";
import ReactDOM from 'react-dom';
// DOM Render HTML
const div = document.getElementById('root'); // DOM
const root = ReactDOM.createRoot(div);
root.render(<App/>)