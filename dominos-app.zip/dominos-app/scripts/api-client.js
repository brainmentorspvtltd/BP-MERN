export function apiCall(URL){
    // ES6 API Call
    // const MAX = 10;
    const promise =fetch(URL); // Async Way
    // States = Pending, FullFilled/ Reject
    return promise;
}