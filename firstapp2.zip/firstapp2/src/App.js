import React from "react";

function App(){
 // return (<h1>Hello React JS</h1>)
 return React.createElement('h1', null, 'Hello React JS');
}
export default App;
