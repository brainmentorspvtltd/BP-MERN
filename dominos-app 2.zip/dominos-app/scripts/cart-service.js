/*
const obj = {
    addInCart : function(){

    },
    removeFromCart:function(){}
}
*/
// ES6 ShortHand Style of Object Creation
const cartOperations = {
addInCart(){

},

removeFromCart(){

},

viewAll(){

},

totalCompute(){

}
}
export default cartOperations;