import React, { useEffect, useState } from 'react'
import { Products } from '../components/Products'
import { Header } from '../../../shared/components/Header'
import { getApi } from '../../../shared/services/api-client';
import { CartView } from '../../carts/pages/CartView';
import { CartContext } from '../context/cart-context';

export const DashBoard = () => {
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState([]);
  //let carts = [];
  const [carts, setCarts]  = useState([]);
  useEffect(()=>{
      getProducts();
  },[]) ; // Mounting
  const addCart = (product)=>{
      const c = [...carts];
      c.push(product);
      setCarts(c);
  }
  const getProducts = async ()=>{
     const data = await getApi();
     console.log('Products ', data);
     setLoading(false);
     setProducts(data['products']);
  }
  return (
    <div className='container'>
      <Header/>
      <CartContext.Provider value = {{carts:carts, addCart: addCart}}>
      <div className = 'row'>
        <div className = 'col-8'>
            <div className = 'row'>
            {loading?<p>Loading...</p>:<Products products = {products}/>}
            </div>
        </div>
        <div className='col-4'>
            <h3 className = 'alert alert-success'>Carts</h3>
            <CartView/>
        </div>
      </div>
      </CartContext.Provider>
     
      
    </div>
  )
}
