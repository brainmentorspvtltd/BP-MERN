import React from 'react'

export const OrderView = () => {
  return (
    <div>OrderView</div>
  )
}
